def script_handler(*args, **kwargs):
    for _ in range(0, 10):
        print("Thor Script Testing")